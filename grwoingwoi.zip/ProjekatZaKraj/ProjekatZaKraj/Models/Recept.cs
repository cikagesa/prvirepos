﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatZaKraj.Models
{
    class Recept
    {
        private string Naziv;
        private string Opis;
        private string Tip;
        public Korisnik Kreator;
        
        public Recept(string Naziv, string Opis, string Tip,
            Korisnik Kreator)
        {
            this.Naziv = Naziv;
            this.Opis = Opis;
            this.Tip = Tip;
            this.Kreator = Kreator;
        }
    }
}
