﻿using ProjekatZaKraj.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatZaKraj
{
    static class Util
    {
        public static Korisnik logovanikiKorisnik;

        public static List<Korisnik> registrovaniKorisnici = new List<Korisnik>();

        public static bool login(string username, string password)
        {
            /*
            registrovaniKorisnici.Find(k)=>{ return Korisnik.KorisnickoIme == username && 
                    Korisnik.Lozinka == password; };

            */
                foreach (Korisnik k in registrovaniKorisnici)
                {
                    if (k.KorisnickoIme.Equals(username) && k.Lozinka.Equals(password))
                    {
                        logovanikiKorisnik = k;
                        return true;
                    }
                        
                }
                return false;
            
            
        }
    }
}
