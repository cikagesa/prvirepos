using ProjekatZaKraj.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjekatZaKraj
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Korisnik k1 = new Korisnik("petar", "123");
            Korisnik k2 = new Korisnik("milka", "123");
            Korisnik k3 = new Korisnik("milica", "123");

            Util.registrovaniKorisnici.Add(k1);
            Util.registrovaniKorisnici.Add(k2);
            Util.registrovaniKorisnici.Add(k3);

            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Views.ReceptLista());

           

        }
    }
}
