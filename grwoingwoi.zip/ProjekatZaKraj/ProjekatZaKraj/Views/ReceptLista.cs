﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjekatZaKraj.Views
{
    class ReceptLista : Form
    {
        private Button Loginbtn = new Button();
        LoginForm loginForm = new LoginForm();
        Label pozdravLbl = new Label();

        public ReceptLista() : base()
        {
            Size = new Size(600, 700);
            Text = "Recepti";
            Loginbtn.Text = "Log in";
            Loginbtn.Location = new Point(450, 50);
            //Loginbtn.Top = 50;
            //Loginbtn.Left = 450;
            Loginbtn.Click += buttonLogin_Click;
            Controls.Add(Loginbtn);

            pozdravLbl.Visible = false;
            Controls.Add(pozdravLbl);
            

        }
        

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            loginForm.Show();

        }
    }
}
