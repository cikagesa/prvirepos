﻿using ProjekatZaKraj.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjekatZaKraj.Views
{
    class LoginForm : Form
    {
        Label lblUserName = new Label();
        Label LblPassword = new Label();
        TextBox TxtUserName = new TextBox();
        TextBox TxtPassword = new TextBox();
        Button LoginBtn = new Button();
        Button CancleBtn = new Button();

        public LoginForm() : base()
        {
            this.Text = "Login";
            this.Size = new Size(300, 250);

            lblUserName.Text = "Unesite username";
            lblUserName.Location = new Point(20, 10);
            Controls.Add(lblUserName);

            LblPassword.Text = "Unesite lozinku";
            LblPassword.Location = new Point(20, 80);
            Controls.Add(LblPassword);

            TxtUserName.Location = new Point(120, 10);
            Controls.Add(TxtUserName);

            TxtPassword.Location = new System.Drawing.Point(200, 80);
            TxtPassword.PasswordChar = '*';
            Controls.Add(TxtPassword);

            LoginBtn.Location = new Point(25, 120);
            LoginBtn.Text = "Login";
            LoginBtn.Click += LoginBtn_Click;
            Controls.Add(LoginBtn);

            CancleBtn.Location = new Point(170, 120);
            CancleBtn.Text = "Cancel";
            CancleBtn.Click += CancleBtn_Click;
            /*
            CancleBtn.MouseEnter += (s, e) =>
              {
                  CancleBtn.BackColor = CancleBtn.BackColor == Color.Red ? Color.Purple : Color.Red;
              };
            */
            Controls.Add(CancleBtn);
            
            
        }

        
       

        private void LoginBtn_Click(object s, EventArgs e)
        {
            if(Util.login(TxtUserName.Text,TxtPassword.Text))
            {
                this.Hide();
                
            }
            else
            {
                MessageBox.Show("Neuspesno logovanje");
            }
        }
        private void CancleBtn_Click(object s, EventArgs e)
        {
            this.Hide();

        }

    }
}
